//console.log('hello world');
/*
  多行注释
*/
console.log('hello world');