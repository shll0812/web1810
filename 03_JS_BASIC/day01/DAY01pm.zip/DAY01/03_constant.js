//声明常量
const d1='2019-1-1';
//d1='2019-1-2';
console.log(d1);
//练习：声明一个常量保存圆周率3.14，声明一个变量保存圆的半径，打印圆的周长和面积
const PI=3.14;
var r=5;
console.log(2*PI*r);
//console.log(0.1+0.2);
console.log(PI*r*r);
