var r=5;
const PI=3.14;
//计算周长
var length=2*PI*r;
console.log(length);
//计算30弧度
console.log(30/360*length);
console.log(60/360*length);
console.log(90/360*length);

var price1=12.5;
var count1=20;
var price2=30;
var count2=8.5;
console.log(price1*count1+price2*count2);





