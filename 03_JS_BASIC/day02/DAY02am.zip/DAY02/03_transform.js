/*
console.log(1+1);
console.log( typeof(1+1) );
console.log(1+'1');//'11'
console.log( typeof(1+'1') );
console.log('a'+'b');
console.log(1+false);//1  false->0
console.log( typeof(1+false) );//number
//查看布尔型和字符串相加的结果和类型分别是
console.log(true+'hello');//'truehello'
console.log( typeof(true+'hello') );//string
*/
//练习：使用 - * /分别执行字符串，数值，布尔型两两之间的运算
console.log(3-'1');
console.log( typeof(3-'1') );
console.log('8'*'1a');//NaN  Not a Number
console.log( typeof('8'*'1a') );








