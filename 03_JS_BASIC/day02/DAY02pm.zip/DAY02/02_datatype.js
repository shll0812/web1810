//1234.56
//1.23456*10^3
//console.log(1.23456E3);
//123456*10^-2
//console.log(123456e-2);
//查看数值型的数据类型
//打印typeof函数的执行结果
/*
console.log( typeof('2') );//number
//字符串型
console.log('hello');
console.log( typeof('hello') );
//查看一个字符的Unicode编码
console.log( '华'.charCodeAt() );
//布尔型
console.log(3>1);
console.log(1<0);
console.log( typeof(true) );
//未定义型
var total;//undefined
console.log( typeof(total) );
console.log(total);
var product1=20*3;
var product2=18*8;
total=product1+product2;
console.log(total);
*/









