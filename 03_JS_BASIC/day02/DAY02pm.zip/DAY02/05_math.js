/*
console.log(3%2); //1
console.log(-3%2);//-1
console.log(5%3);//2
console.log(2%3);//2

var num=1;
//自增：在原来的基础之上加1
//num++;
//自减：在原来的基础之上减1
//num--;
//先打印num的值，然后再去执行自增
//console.log(num++);
//console.log(num);
//先执行自增，然后再去打印num的值
console.log(++num);
*/
/*
var a=3;
a++;//4
a++;//5
a--;//4
console.log(a);
*/
var b=7;
//先取出b的值————7，然后再去b执行自增————8
//先让b执行自增————9，然后再取出b的值————9
console.log(b++ + ++b);







