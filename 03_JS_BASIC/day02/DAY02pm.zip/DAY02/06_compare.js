//console.log(3>1);//true
//console.log(1==1);//true
//console.log(1=='1');//true
//console.log(1==='1');//false

//console.log(3>'10');//false
//console.log('3'>'10');
//'3' -> 51  '1'->49
//console.log( '1'.charCodeAt() );
//华  燕
//console.log('华'>'燕');
//'10a'转成数字  ->  NaN 
console.log(3>'10a');
console.log(3<'10a');
console.log(3=='10a');
console.log(NaN==NaN);
console.log(NaN!=NaN);








