//判断成绩优秀  90~100
/*
var score=92;
console.log(score>=90 && score<=100);
//老人或者小孩门票半价
//65岁以上   12岁以下
var age=66;
console.log(age>=65 || age<=12);
console.log( !(3>1) );
var uname='abc';
var upwd='123456';
console.log(uname=='root' && upwd=='123456');

var age=93;
console.log(age>=90 || age<=3);

//逻辑短路
var num=3;
num>5 && console.log(a);
num<1 || console.log(a);
*/
//练习：声明一个变量保存年龄，如果年龄大于等于18岁，打印‘成年人’
var age=5;
age>=18 && console.log('成年人');



