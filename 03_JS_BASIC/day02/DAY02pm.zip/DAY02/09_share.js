//赋值运算符
var a=1;
//a++;
//在原来的基础之上加3
//a=a+3;
//等价于a=a+3
//a+=3;
a-=3;
console.log(a);
var price=88;
//打五折
price*=0.5;
console.log(price);




