//三目运算符
//判断一个人的年龄是否为成年人
//是，打印“成年人”   不是，打印“未成年人”
/*
var age=9;
age>=18 ? console.log('成年人') : console.log('未成年人');
//练习：声明两个变量，分别保存两个数字；比较两个数字的大小，打印最大值的变量名。
var num1=3;
var num2=10;
num1>num2 ? console.log(num1) : console.log(num2);
*/
//练习：声明两个变量，分别保存用户名和密码；如果用户名是root，并且密码是123456，打印“登录成功”，否则打印“登录失败”
var uname='root';
var upwd='123456';
uname=='root' && upwd=='123456' ? console.log('登录成功') : console.log('登录失败');




