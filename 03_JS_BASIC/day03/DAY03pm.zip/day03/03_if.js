/*
var total=29;
//判断总价是否满30，如果满30减15
if(total>=30){
  //在原来基础之上减15
  total-=15; //total=total-15;
}
console.log('应付金额：'+total);
//练习：声明变量保存年龄，如果年龄大于60，在原来的基础之上减5，打印最终年龄。
var age=59;
if(age>60){
  age-=5;
}
console.log(age);
*/
//练习：声明两个变量分别保存用户名和密码，如果用户名是root，并且密码是123456；打印登录成功
/*var uname='root';
var upwd='123456';

if(uname=='root' && upwd=='123456'){
  console.log('登录成功');
}

//逻辑短路写法
(uname=='root' && upwd=='123456') &&  console.log('登录成功');
//if大括号只有一行，可以省略大括号
var age=17;
if(age>=18)
  console.log('成年人');
*/
//false: 0，NaN，''，undefined，null
if(null){
  console.log(1);
}










