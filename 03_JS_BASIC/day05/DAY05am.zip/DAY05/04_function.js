/*
function play(){
  console.log('吃火锅了');
  console.log('吃海鲜了');
  console.log('看表演了');
  return '工艺品';
}
//函数的返回结果
//过程中带什么回来？
var res=play();
console.log(res);

function add(num1,num2){
  //表示在过程中执行了打印
  //不代表返回的结果
  //console.log(num1+num2);
  //返回两个数字相加的结果
  return num1+num2;
}
//把函数add的调用结果放到变量中
var res=add(2,3);
console.log(res+'元');
function add(num1,num2,num3){
  //return num1+num2+num3;
  //只需要得到结果，结果显示到哪后期项目中的位置
  //return;//undefined
  console.log(123);
  return '火锅底料';
  console.log('hello world');
}
var res=add(3,5,7);
console.log(res);

*/
function getMax(num1,num2){
  if(num1>num2){
    return num1;
  }else{
    return num2;
  }
}
var res=getMax(5,7)
console.log(res);



