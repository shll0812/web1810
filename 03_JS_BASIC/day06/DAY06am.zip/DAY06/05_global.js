var str='http://www.jd.com:80/Search?kw=手机';
console.log(str);
//对url中的中文进行编码
str=encodeURI(str);
console.log(str);
//对已编码的url进行解码
str=decodeURI(str);
console.log(str);








