/*
var str='http://www.jd.com:80/Search?kw=手机';
console.log(str);
//对url中的中文进行编码
str=encodeURI(str);
console.log(str);
//对已编码的url进行解码
str=decodeURI(str);
console.log(str);
var res=parseInt('a3');
//查看一个数据是否为NaN
console.log( isNaN(res) );
*/
//console.log(-1/0);//Infinity 无穷大
//检测一个数据是否为有限值
//console.log( isFinite(1/0) );

console.log( eval('1+2') );
eval('function fn(){console.log(123);}');
fn();


