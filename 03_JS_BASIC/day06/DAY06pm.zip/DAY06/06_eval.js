//弹出提示框
var str=prompt('please input');
console.log(eval(str));