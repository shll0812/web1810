//创建一个手机对象
//{属性名:属性值,...}
/*
var phone={
  color:'red',
  brand:'Apple',
  size:5.7,
  'price':2000,
  'made-in':'china'
};
console.log(phone);
*/
//练习：创建一个部门对象，属性有部门编号，名称，员工数量
var dept={
  did:10,
  dname:'研发部',
  count:5
}
console.log(dept);
//练习：创建一个员工对象，属性有编号，姓名，性别，生日，工资，所在部门
var emp={
  eid:2,
  ename:'tom',
  sex:1,
  birthday:'1993-5-20',
  salary:10000,
  deptId:10
};
console.log(emp);






