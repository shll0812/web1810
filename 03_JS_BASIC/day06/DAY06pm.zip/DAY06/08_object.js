//使用内置构造函数创建对象
/*
var book=new Object();
//添加属性
book.id=103;
book.title='三国演义';
book['price']=219;
book['publish']='人民邮电出版社';
console.log(book);
//汽车对象
var car=new Object();
car.cid=101;
car.brand='奇瑞QQ';
car.color='red';
car.price=40000;
console.log(car);
*/
//电脑对象
var computer=new Object();
computer['id']='thinkPad';
computer['brand']='LENOVO';
computer['size']=15.6;
computer['madeIn']='china';
console.log(computer);




















