var person1={
  name:'tom',
  age:18
}
//复制person1的地址给person2
//此时两个变量指向同一个地址
//无论使用哪一个变量改变对象中的属性值，另一个也会发生变化
var person2=person1;
//改变person1的name属性值
person1.name='jerry';
console.log(person2.name);
//person2.age=20;
//console.log(person1.age);
/*
var a=1;
//赋值a变量中的值给b变量
var b=a;//1
//只是改变a变量的值，和b没有关系
a=3;
console.log(a);//3
console.log(b);//1
*/














