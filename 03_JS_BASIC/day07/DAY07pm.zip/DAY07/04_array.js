/*
var country=[];
country[country.length]='中国';
country[country.length]='美国';
country[country.length]='法国';
//console.log(country);
//不存在的元素——undefined
console.log(country[3]);//

var arr=new Array(5);
arr[5]='tom';
console.log(arr);
console.log(arr.length);
*/
//创建关联数组
var arr=[];
//添加元素
arr['eid']=1;
arr['ename']='tom';
arr[0]=20;
console.log(arr);








