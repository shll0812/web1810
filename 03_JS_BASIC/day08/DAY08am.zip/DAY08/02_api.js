var arr=['推荐','热点','娱乐'];
//往数组的末尾添加元素
//arr[arr.length]='新闻';
//console.log(arr.push('汽车'));
//删除数组末尾的元素
//console.log(arr.pop());
//往数组的开头添加元素
//console.log(arr.unshift('体育'));
//删除数组开头的元素
console.log(arr.shift());
console.log(arr);







