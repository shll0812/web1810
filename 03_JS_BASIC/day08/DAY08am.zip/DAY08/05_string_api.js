var str='WelCome To China';
//转为大写
console.log(str.toUpperCase());
//转为小写
console.log(str.toLowerCase());