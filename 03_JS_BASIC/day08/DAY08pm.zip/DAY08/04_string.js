/*
var str1='hello';
//将数据包装成字符串对象
var str2=new String('hello');
var str3=String(true);
//console.log(typeof(str1));
//console.log(str2);
//console.log(typeof(str2));
//console.log(str1+'world');
//console.log(str2+'world');
console.log(str3);
console.log(typeof(str3));
//  \ 转义   \n转义成了换行符
console.log('hello \n world');
console.log('hello\tworld');
console.log('it\'s a dog');
*/
console.log('welcome to chi\\na');




