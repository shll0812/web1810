//Math对象
//console.log(Math.PI);
//绝对值  absolute
//console.log(Math.abs(-3));
//
//console.log(parseInt(4.8));
//向下取整
//console.log(Math.floor(5.3));
//向上取整
//console.log(Math.ceil(5.3));
//四舍五入取整
//console.log(Math.round(5.5));
//获取一组数字的最大值
//console.log(Math.max(9,23,45,78,6));
//获取一组数字的最小值
//console.log(Math.min(9,23,45,78,6));
//获取x的y次幂
//console.log(Math.pow(3,4));
//获取随机
//0~1*21  0.001~20.234   0~20
//console.log(Math.random()); //  >=0  <1
var res=Math.floor(Math.random()*5);//0~4 
console.log(res);
