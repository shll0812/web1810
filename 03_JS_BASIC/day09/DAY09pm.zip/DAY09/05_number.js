//var num1=new Number(1);
//var num2=1;
//var num3=new Number('10a');
var num4=Number(true);
//console.log(num4);
// - *  / 自动调用Number转为数值
//console.log('1'-true);
//console.log(num3);
//console.log(num1);
//console.log(typeof(num1));
//console.log(num1+3,num2+3);
//console.log(Number.MAX_VALUE);
//console.log(Number.MIN_VALUE);
console.log(2*5*3.14);
var num=2*5*3.14;
//保留小数点后几位
console.log(num.toFixed(3));
var num5=10;
//将数字转为字符串
//console.log( typeof(num5.toString()) );
num5=num5+'';
console.log(typeof(num5));



