//undefined  NaN  0  ''  null
//var b1=new Boolean(undefined);
//console.log(b1,typeof(b1));
//var b2=Boolean(' ');
//console.log(b2);
//console.log(Boolean([]));  //true
//console.log(Boolean({}));
//console.log(!!0);
//console.log(typeof(null));
var b2=true;
console.log( typeof(b2.toString()) );







