var a=1;
function fn(){
  console.log(123);
}
console.log(window.a);
window.fn();