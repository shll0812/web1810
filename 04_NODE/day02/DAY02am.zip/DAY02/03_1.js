//引入当前目录下的03_2目录模块
var obj=require('./03_2');
console.log(obj);
obj.fn(3,5);