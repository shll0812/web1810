//引入功能模块circle.js
//自定义模块格式为js结尾的，可以省略后缀名.
var circle=require('./circle.js');
//console.log(circle);
console.log(circle.getLength(5));
console.log(circle.getArea(5));