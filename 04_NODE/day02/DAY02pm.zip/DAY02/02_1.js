//引入02_2目录模块
//默认会自动寻找02_2目录下的index.js文件
require('./02_2');
//require('./02_2/test.js');