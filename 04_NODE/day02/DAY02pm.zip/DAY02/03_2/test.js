console.log('./03_2/test.js');
function fn(a,b){
  console.log(a+b);
}
//导出函数fn
module.exports.fn=fn;