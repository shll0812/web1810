const express = require('express');

var app = express();
//新浪云中的Node.js服务器不允许使用其它端口！！
//客户端请求的是80，新浪云内部自动转向到5050端口
app.listen(5050);

app.get('/', (req, res)=>{
	res.send('hello 1810 ... ');
})